<div class="row">

    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-4 mb-4">

        <div class="card shadow-sm border-0 h-100">

            <img src="<?php echo e(asset('uploads/'.$blog->image)); ?>"
                 class="card-img-top"
                 style="height:220px; object-fit:cover;">

            <div class="card-body">

                <span class="badge bg-primary mb-2">
                    <?php echo e($blog->category->name ?? 'General'); ?>

                </span>

                <h4><?php echo e($blog->title); ?></h4>

                <p class="text-muted">
                    <?php echo e($blog->short_description); ?>

                </p>

          <a href="<?php echo e(route('blogs.show', $blog->id)); ?>"
   class="btn btn-dark">
    Read More
</a>

            </div>

        </div>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH D:\PROJECTS\blog-management-system\resources\views/partials/blogs.blade.php ENDPATH**/ ?>