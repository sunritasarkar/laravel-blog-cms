

<?php $__env->startSection('content'); ?>

<h2 class="mb-4">All Blogs</h2>

<a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary mb-3">
    Add Blog
</a>
<table class="table table-bordered">

    <thead>

        <tr>

            <th>Title</th>
            <th>Category</th>
            <th>Date</th>
            <th>Actions</th>

        </tr>

    </thead>

    <tbody>

        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>

            <td>
    <a href="<?php echo e(route('blogs.show', $blog->id)); ?>">
        <?php echo e($blog->title); ?>

    </a>
</td>

            <td><?php echo e($blog->category->name ?? 'No Category'); ?></td>

            <td><?php echo e($blog->published_at); ?></td>

            <td>
                <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>"
                class="btn btn-sm btn-warning">
                Edit
                </a>

                <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>"
      method="POST"
      style="display:inline;">

    <?php echo csrf_field(); ?>

    <?php echo method_field('DELETE'); ?>

    <button class="btn btn-danger btn-sm">
        Delete
    </button>

</form>

            </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECTS\blog-management-system\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>