

<?php $__env->startSection('content'); ?>

<h1 class="mb-3">
    <?php echo e($blog->title); ?>

</h1>

<p class="text-muted">
    Category: <?php echo e($blog->category->name ?? 'No Category'); ?>

</p>

<img src="<?php echo e(asset('uploads/'.$blog->image)); ?>"
     width="300"
     class="mb-4">

<div class="border p-4 bg-light rounded">

    <?php echo $blog->content; ?>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECTS\blog-management-system\resources\views/admin/blogs/show.blade.php ENDPATH**/ ?>